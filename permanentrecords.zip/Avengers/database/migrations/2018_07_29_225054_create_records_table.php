<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRecordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('records', function (Blueprint $table) {
            $table->increments('id');
	    $table->integer('artist_id')->nullable(false);
	    $table->integer('label_id')->nullable(false);
	    $table->integer('format_id')->nullable(false);
	    $table->string('title',200)->nullable(false);
	    $table->char('year',4);
	    $table->string('country');
	    $table->string('state',20);
	    $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('records');
    }
}
