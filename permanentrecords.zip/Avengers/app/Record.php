<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Record extends Model
{
    //
	protected $fillable = ['artist_id', 'label_id', 'format_id', 'title', 'year', 'country', 'state'];

	public function artists() {
		return $this->hasOne('App\Artist');
	}

	public function labels() {
		return $this->belongsTo('App\Label');
	}
}
