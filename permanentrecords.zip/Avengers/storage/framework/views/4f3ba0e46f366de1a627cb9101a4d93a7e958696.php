<?php $__env->startSection('content'); ?>
        <div class="title m-b-md px-5">
                <h1><a href="<?php echo e(URL::to('/artists')); ?>">Artists</a> >> <strong><?php echo e($artist->name); ?></h1>
        </div>

	<div>
		<h2><?php echo e($artist->name); ?></h2>
		<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<p><a href="<?php echo e(URL::to('/records/show',$record->id)); ?>"><?php echo e($record->title); ?></a></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>