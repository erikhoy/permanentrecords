<?php $__env->startSection('content'); ?>
	<div class="title m-b-md">
		<h2>Labels</h2>
	</div>

	<div class="table-responsive">
		<table class="table table-hover table-bordered table-striped">
			<thead class="thead-dark">
				<th scope="col">Label</th>
				<th scope="col">Record</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 
						$records = \App\Record::where('label_id',$label->id)
							->orderBy('title', 'asc')
							->get();
					?>
					<tr>
						<td><a href="<?php echo e(URL::to('/labels/show', $label->id)); ?>"><strong><?php echo e($label->name); ?></strong></a></td>
						<td class="pt-2">
							<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$artist = \App\Artist::where('id', $record->artist_id)
										->first();
								?>
								<i class="fas fa-dot-circle px-2"></i><?php echo e($artist->name); ?> &mdash; <?php echo e($record->title); ?><br>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>