<?php $__env->startSection('content'); ?>
	<div class="title m-b-md">
		<h1>Records</h1>
	</div>
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover">
			<thead class="thead-dark">
				<tr>
					<th scope="col">Title</th>
					<th scope="col">Artist</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 
						$artist = App\Artist::where('id', $record->artist_id)
							->first();
					?>
					<tr>
						<td><strong><a href="<?php echo e(URL::to('/records/show', $record->id)); ?>"><?php echo e($record->title); ?></a></strong></td>
						<td><a href="<?php echo e(URL::to('/artists/show', $artist->id)); ?>"><?php echo e($artist->name); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>