<?php $__env->startSection('content'); ?>
        <div class="title m-b-md px-5">
                <h1><a href="<?php echo e(URL::to('/records')); ?>">Records</a> >> <strong><?php echo e($record->title); ?></h1>
	</div>
	<div>
		<h2><?php echo e($record->title); ?> &mdash; <a href="<?php echo e(URL::to('/artists/show', $artist->id)); ?>"><?php echo e($artist->name); ?></a></h2>
		<p><?php echo e($record->year); ?></p>
		<p><?php echo e($record->country); ?></p>
		<p><iframe src="https://open.spotify.com/embed/album/2D5MHyn5eH18usOLYpRvhs" width="300" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe></p>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>