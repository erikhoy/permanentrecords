@extends('layouts.app')
@section('content')
        <div class="title m-b-md px-5">
                <h1><a href="{{ URL::to('/labels') }}">Labels</a> >> <strong>{{ $label->name }}</h1>
	</div>
	<div>
		<h2>{{ $label->name }}</h2>
		@foreach(<p>{{ $->year }}</p>
		<p>{{ $record->country }}</p>	
	</div>
@endsection

