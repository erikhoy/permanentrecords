@extends('layouts.app')
@section('content')
	<div class="title m-b-md">
		<h2>Labels</h2>
	</div>

	<div class="table-responsive">
		<table class="table table-hover table-bordered table-striped">
			<thead class="thead-dark">
				<th scope="col">Label</th>
				<th scope="col">Record</th>
			</thead>
			<tbody>
				@foreach($labels as $label)
					@php 
						$records = \App\Record::where('label_id',$label->id)
							->orderBy('title', 'asc')
							->get();
					@endphp
					<tr>
						<td><a href="{{ URL::to('/labels/show', $label->id) }}"><strong>{{ $label->name }}</strong></a></td>
						<td class="pt-2">
							@foreach($records as $record)
								@php
									$artist = \App\Artist::where('id', $record->artist_id)
										->first();
								@endphp
								<i class="fas fa-dot-circle px-2"></i>{{ $artist->name }} &mdash; {{ $record->title }}<br>
							@endforeach
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
@endsection
