@extends('layouts.app')
@section('content')
	<div class="title m-b-md">
		<h2>Covers</h2>
	</div>
@endsection
