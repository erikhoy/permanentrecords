@extends('layouts.app')
@section('content')
        <div class="title m-b-md px-5">
                <h1><a href="{{ URL::to('/records') }}">Records</a> >> <strong>{{ $record->title }}</h1>
	</div>
	<div>
		<h2>{{ $record->title }} &mdash; <a href="{{ URL::to('/artists/show', $artist->id) }}">{{ $artist->name }}</a></h2>
		<p>{{ $record->year }}</p>
		<p>{{ $record->country }}</p>
		<p><iframe src="https://open.spotify.com/embed/album/2D5MHyn5eH18usOLYpRvhs" width="300" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe></p>
	</div>
@endsection

