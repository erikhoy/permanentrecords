@extends('layouts.app')
@section('content')
	<div class="title m-b-md">
		<h1>Records</h1>
	</div>
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover">
			<thead class="thead-dark">
				<tr>
					<th scope="col">Title</th>
					<th scope="col">Artist</th>
				</tr>
			</thead>
			<tbody>
				@foreach($records as $record)
					@php 
						$artist = App\Artist::where('id', $record->artist_id)
							->first();
					@endphp
					<tr>
						<td><strong><a href="{{ URL::to('/records/show', $record->id) }}">{{ $record->title }}</a></strong></td>
						<td><a href="{{ URL::to('/artists/show', $artist->id) }}">{{ $artist->name }}</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
@endsection
