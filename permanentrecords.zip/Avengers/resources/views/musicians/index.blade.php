@extends('layouts.app')
@section('content')
	<div class="title m-b-md">
		<h2>Musicians</h2>
	</div>
@endsection
