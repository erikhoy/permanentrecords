@extends('layouts.app')
@section('content')
	<div class="title m-b-md px-5">
		<h1>Artists</h1>
	</div>

	<div class="table-responsive">
		<table class="table table-striped table-hover table-bordered">
			<thead class="thead-dark">
				<tr>
					<th scope="col">Artist</th>
					<th scope="col">Title</th>
				</tr>
			<thead>
			<tbody>
			@foreach($artists as $artist)
                		@php 
                        		$records = \App\Record::where('artist_id', $artist->id)
                                		->orderBy('title')
                                		->get();
                		@endphp
				<tr>
					<td><a href="{{ URL::to('/artists/show',$artist->id) }}"><strong>{{ $artist->name }}</strong></a></td>
					<td>
						@foreach($records as $record)
                                        		<i class="fas fa-dot-circle px-2"></i><a href="{{ URL::to('/records/show', $record->id) }}"> {{ $record->title }}</a><br>
                                		@endforeach
                        		</td>
                		</tr>
        		@endforeach
			</tbody>
		</table>
	</div>
@endsection
