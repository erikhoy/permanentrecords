@extends('layouts.app')
@section('content')
        <div class="title m-b-md px-5">
                <h1><a href="{{ URL::to('/artists') }}">Artists</a> >> <strong>{{ $artist->name }}</h1>
        </div>

	<div>
		<h2>{{ $artist->name }}</h2>
		@foreach($records as $record)
			<p><a href="{{ URL::to('/records/show',$record->id) }}">{{ $record->title }}</a></p>
		@endforeach	
	</div>
@endsection

